#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import datetime
import serial
import time
import sys
import csv


from plexus.nodes.node import BaseNode, PeriodicCallback, Message
from plexus.utils.console_client_api import PlexusUserApi
from plexus.nodes.command import Command
from plexus.devices.simple_avr_relay_device import AVRRelayDevice


class StandControlNode(BaseNode):
    """

    """
    def __init__(self, endpoint: str, network: list):
        super().__init__(endpoint, network)

        self.avr_relay_dev = AVRRelayDevice(
            name="avr_relay",
            num_of_channels=6,
            dev='/dev/ttyUSB0',
            baud=9600,
            timeout=1,
            slave_id=1
        )

        self._annotation = "control node for relay control"
        self._devices.extend([self.avr_relay_dev])


        self.logger("my system commands")
        self.logger(self.system_commands)

        self.system_stage_flag = "waiting for the start of cycle"

        # channels on real device
        self.mixing_pump = 1
        self.output_valve = 2
        self.dosing_pump = 3
        self.input_pump = 4

        # exp data storaging
        self.out_file = "out.csv"
        self.blink_flag = False

    def custom_preparation(self):
        self.logger("custom init")
        # self.system_stage_flag = "waiting for the start of cycle"
        # self.system_timer = PeriodicCallback(self.on_system_timer, self.time_quant)  # ms
        # self.system_timer = PeriodicCallback(self.on_data_saving, self.measure_pause)  # ms
        # self.system_timer.start()
        self.logger("start work")

    # def on_data_saving(self):
    #     if self.blink_flag:
    #         self.blink_flag = False
    #         self.avr_relay_dev(command="off", **{"channel": 1})
    #     else:
    #         self.blink_flag = True
    #         self.avr_relay_dev(command="on", **{"channel": 1})


    def handle_custom_system_msgs(self, stream, reqv_msg: Message):
        addr_decoded, decoded_dict = Message.parse_zmq_msg(reqv_msg)
        pass



if __name__ == "__main__":
    print("we are awaiting tcp addr in format 10.9.0.1")

    # u_to_e_approximation()

    # we are awaiting addr as 10.9.0.1
    my_addr = str(sys.argv[1])
    print(type(my_addr))

    network1 = [
        # {"name": "node104", "address": "tcp://{}:5568".format(my_addr)}
        # {"name": "node2", "address": "tcp://10.9.0.12:5567"},
        {"address": "tcp://{}:5569".format(my_addr)}
    ]
    n1 = StandControlNode(endpoint=network1[0]['address'], network=network1)
    n1.start()
    n1.join()

